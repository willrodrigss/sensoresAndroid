package com.example.sensores;

import static android.content.Context.SENSOR_SERVICE;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.view.View;
import android.widget.RadioGroup;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private SensorManager sensorManager;
    private Sensor prox, acel, lum;

    ListenerProx l_prox;
    ListenerAcel l_acel;
    ListenerLum l_lum;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //criando gerenciador de sensores
        sensorManager = (SensorManager)getSystemService(SENSOR_SERVICE);

        //atribuindo os sensores
        prox = sensorManager.getDefaultSensor(Sensor.TYPE_PROXIMITY);
        acel = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        lum = sensorManager.getDefaultSensor(Sensor.TYPE_LIGHT);

        //registrando os listeners aos sensores com os delays
        l_prox = new ListenerProx();
        sensorManager.registerListener(l_prox, prox, SensorManager.SENSOR_DELAY_UI);

        l_acel = new ListenerAcel();
        sensorManager.registerListener(l_acel, acel, SensorManager.SENSOR_DELAY_UI);

        l_lum = new ListenerLum();
        sensorManager.registerListener(l_lum, lum, SensorManager.SENSOR_DELAY_UI);
    }

    @Override
    protected void onPause(){
        super.onPause();
        sensorManager.unregisterListener(l_prox);
        sensorManager.unregisterListener(l_acel);
        sensorManager.unregisterListener(l_lum);
    }

    TextView recebeDados;


    class ListenerProx implements SensorEventListener {

        public float distancia;

        @Override
        public void onSensorChanged(SensorEvent sensorEvent) {
            distancia = sensorEvent.values[0];
            recebeDados = findViewById(R.id.dados);
            recebeDados.setText("Distância capturada: " + distancia);
        }

        public void onAccuracyChanged(Sensor sensor, int i) {

        }
    }

    class ListenerAcel implements SensorEventListener{

        public float acelerometro;

        @Override
        public void onSensorChanged(SensorEvent sensorEvent){
            recebeDados = findViewById(R.id.dados);
            acelerometro = sensorEvent.values[0];
            recebeDados.setText("Dados acelerômetro: " + acelerometro);
        }

        public void onAccuracyChanged(Sensor sensor, int i){

        }
    }

    class ListenerLum implements SensorEventListener{

        public float luminosidade;

        @Override
        public void onSensorChanged(SensorEvent sensorEvent){
            recebeDados = findViewById(R.id.dados);
            luminosidade = sensorEvent.values[0];
        }

        public void onAccuracyChanged(Sensor sensor, int i){

        }
    }

    public void realizarLeitura(View v){

        RadioGroup grupo = findViewById(R.id.opcaoSensores);
        int idSelect = grupo.getCheckedRadioButtonId();

        switch(idSelect){
            case R.id.proximidade:
                recebeDados.setText("Distância medida: " + l_prox.distancia);
                break;

            case R.id.acelerometro:
                recebeDados.setText("Dados acelerômetro: " + l_acel.acelerometro);
                break;

            case R.id.luminosidade:
                recebeDados.setText("Luminosidade: " + l_lum.luminosidade);
                break;
        }

        Intent intent = new Intent(this, DadosActivity.class);
        startActivity(intent);
    }

}